<?php
require_once dirname(__FILE__) . '/data/AttributeInterface.php';
require_once dirname(__FILE__) . '/data/TagInterface.php';
require_once dirname(__FILE__) . '/data/AllowedAttributes.php';
require_once dirname(__FILE__) . '/data/AllowedTags.php';
require_once dirname(__FILE__) . '/Sanitizer.php';